﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Author: Joewe Ntwanano Khosa
 * Date:  28-09-2018
 * Name:  texteditor5
 */

namespace texteditor5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            {//Checks if there is text in the rich text box and the button is checked
                if (richTextBox1.Text.Length > 0 && radioButton1.Checked == true)
                {//checks if the text is selected, if not, apply to all
                    if (richTextBox1.SelectedText == "" || richTextBox1.SelectedText == null)
                    {
                        richTextBox1.SelectAll();
                        richTextBox1.SelectedText = richTextBox1.SelectedText.ToUpper();
                    }
                    else
                    {//else, if text is not selected, update all texts colour
                        richTextBox1.SelectedText = richTextBox1.SelectedText.ToUpper();
                        richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                        richTextBox1.SelectionLength = 0;
                        richTextBox1.SelectionFont = richTextBox1.Font;
                        int selstart = richTextBox1.SelectionStart;
                        int sellength = richTextBox1.SelectionLength;
                        richTextBox1.Select(selstart, sellength);
                    }
                }
                else
                {//will display a warning if no text is entered and the button is selected
                    if (radioButton1.Checked == true)
                    {
                        DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
        }

        private void lowerCaseB_CheckedChanged(object sender, EventArgs e)
                {//Checks if there is text in the rich text box and the button is checked
            if (richTextBox1.Text.Length > 0 && lowerCaseB.Checked == true)
            {//checks if the text is selected, if not, apply to all
                if (richTextBox1.SelectedText == "" || richTextBox1.SelectedText == null)
                {
                    richTextBox1.SelectAll();
                    richTextBox1.SelectedText = richTextBox1.SelectedText.ToLower();
                }
                else
                {
                    richTextBox1.SelectedText = richTextBox1.SelectedText.ToLower();
                    richTextBox1.SelectionStart =richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }
            }

            else
            {//will display a warning if no text is entered and the button is selected
                if (lowerCaseB.Checked == true)
                {
                    DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {//Popup message as soon as this is clicked to advise that current work will be lost
            DialogResult result = MessageBox.Show("All current work will be lost.  Continue ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {//sets the text box content to blank, white background and clears the radio buttons
                richTextBox1.Text = string.Empty;
                richTextBox1.BackColor = Color.White;
                radioButton1.Checked = false;
                lowerCaseB.Checked = false;

            }

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {//Popup message as soon as this is clicked to advise that current work will be lost
            DialogResult result = MessageBox.Show("All current work will be lost.  Continue ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {//openFileDialog properties which can be set in the interface as well
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.InitialDirectory = @"C:\";
                openFileDialog1.Title = "Browse Text Files";
                openFileDialog1.CheckFileExists = true;
                openFileDialog1.CheckPathExists = true;
                openFileDialog1.DefaultExt = "txt";
                openFileDialog1.Filter = "Text files (*.txt)|*.txt";
                openFileDialog1.FilterIndex = 2;
                openFileDialog1.RestoreDirectory = true;
                openFileDialog1.ReadOnlyChecked = true;
                openFileDialog1.ShowReadOnly = true;

                //once "OK" is selected after the file is chosen
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {//this will display the content of the file
                    richTextBox1.Text = System.IO.File.ReadAllText(openFileDialog1.FileName);
                }
            }

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {//checks if there is content in the text box
            if (richTextBox1.Text.Length > 0)
            {//this fucntion set the text back to normal / regular text if it is already bold
                if (richTextBox1.SelectionFont.Bold)
                {
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Regular);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }

                else
                {//sets the text to bold
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Bold);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = -richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }
            }
            else
            {//Popup message will display if no text is selected with a "Warning" title and message icon
                DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {//checks if there is content in the  rich text box
            if (richTextBox1.Text.Length > 0)
            {//this fucntion set the text back to normal / regular text if it is already Italic
                if (richTextBox1.SelectionFont.Italic)
                {
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Regular);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }

                else
                {//sets the text to italic
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Italic);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = -richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }
            }
            else
            {//Popup message will display if no text is selected with a "Warning" title and message icon
                DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {//checks if there is content in the  rich text box
            if (richTextBox1.Text.Length > 0)
            {//this fucntion set the text back to normal / regular text if it is already underlined
                if (richTextBox1.SelectionFont.Underline)
                {
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Regular);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }

                else
                {//sets the text to underlined
                    richTextBox1.SelectionFont = new Font(richTextBox1.Font, FontStyle.Underline);
                    richTextBox1.SelectionStart = richTextBox1.SelectionStart + richTextBox1.SelectionLength;
                    richTextBox1.SelectionLength = 0;
                    richTextBox1.SelectionFont = richTextBox1.Font;
                    int selstart = richTextBox1.SelectionStart;
                    int sellength = -richTextBox1.SelectionLength;
                    richTextBox1.Select(selstart, sellength);
                }
            }
            else
            {//Popup message will display if no text is selected with a "Warning" title and message icon
                DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void toolStripButton1_Click_2(object sender, EventArgs e)
        {//check if there is currently text in the rich text box
            if (richTextBox1.Text.Length > 0)
            {//checks the font selected and text selected
                if (fontDialog1.ShowDialog() == DialogResult.OK && richTextBox1.SelectedText != null)
                {//sets the font selection to the selected text
                    richTextBox1.SelectionFont = fontDialog1.Font;
                }
            }
            else
            {//Dispalys a warning if there is no text in the rich text box
                DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {
        
        }

        private void fontColour_Click(object sender, EventArgs e)
        {//checks if there is currently text in the rich text box
            if (richTextBox1.Text.Length > 0)
            {//displays colour dialog box with below properties
                ColorDialog colorDlg = new ColorDialog();
                colorDlg.AllowFullOpen = false;
                colorDlg.AnyColor = true;
                colorDlg.SolidColorOnly = false;
                colorDlg.Color = Color.Red;

                if (colorDlg.ShowDialog() == DialogResult.OK)
                {//if text is selected, updates the selection font colour
                    if (richTextBox1.SelectedText != null && richTextBox1.SelectedText != "")
                    {
                        richTextBox1.SelectionColor = colorDlg.Color;
                    }
                    else
                    {//else, if text is not selected, update all texts colour
                        richTextBox1.SelectAll();
                        richTextBox1.SelectionColor = colorDlg.Color;
                    }
                }
            }
            else
            {//if there is no text in the rich text box, the below warning will be displayed
                DialogResult result = MessageBox.Show("There is no text", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {//displays colour dialog box
            ColorDialog colorDlg = new ColorDialog();
            if (colorDlg.ShowDialog() == DialogResult.OK)
            {//sets the background colour of the rich text box
                richTextBox1.BackColor = colorDlg.Color;
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void ComboBox_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {//Loads content in the Combo box when the form runs
            comboBox.Text = "Select a word...";

            comboBox.Items.AddRange(new object[]
            {
                "Adding",
                "These",
                "Random",
                "Words",
                "To",
                "The",
                "Rich Text Box",
            });
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void smilingEmo_Click(object sender, EventArgs e)
        {//uses clipboard / paste to copy and paste smile in the rich text box
            System.Drawing.Image happyEmo = texteditor5.Properties.Resources.happyEmo;
            Clipboard.SetDataObject(happyEmo);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {//If, else checks the value of the combo box and adds the combobox text to the existing text.  A case..switch could also have been used
            if (comboBox.SelectedIndex == 0)
            {
                richTextBox1.Text = richTextBox1.Text + "Adding";
            }
            else if (comboBox.SelectedIndex == 1)
            {
                richTextBox1.Text = richTextBox1.Text + "These";
            }
            else if (comboBox.SelectedIndex == 2)
            {
                richTextBox1.Text = richTextBox1.Text + "Random";
            }
            else if (comboBox.SelectedIndex == 3)
            {
                richTextBox1.Text = richTextBox1.Text + "Words";
            }
            else if (comboBox.SelectedIndex == 4)
            {
                richTextBox1.Text = richTextBox1.Text + "To";
            }
            else if (comboBox.SelectedIndex == 5)
            {
                richTextBox1.Text = richTextBox1.Text + "The";
            }
            else
            {
                richTextBox1.Text = richTextBox1.Text + "Rich Text Box";
            }

        }

        private void sadEmoB_Click(object sender, EventArgs e)
        {//uses clipboard / paste to copy and paste sadEmo in the rich text box
            System.Drawing.Image sadEmo = texteditor5.Properties.Resources.sadEmo;
            Clipboard.SetDataObject(sadEmo);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);
        }

        private void toolStripButton3_Click_1(object sender, EventArgs e)
        {//uses clipboard / paste to copy and paste cry in the rich text box
            System.Drawing.Image cry = texteditor5.Properties.Resources.cry;
            Clipboard.SetDataObject(cry);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {//uses clipboard / paste to copy and paste inLove in the rich text box
            System.Drawing.Image inLove = texteditor5.Properties.Resources.inLove;
            Clipboard.SetDataObject(inLove);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {//uses clipboard / pasgggte to copy and paste heart in the rich text box
            System.Drawing.Image heart = texteditor5.Properties.Resources.heart;
            Clipboard.SetDataObject(heart);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {//uses clipboard / paste to copy and paste sad in the rich text box
            System.Drawing.Image sad = texteditor5.Properties.Resources.sad;
            Clipboard.SetDataObject(sad);
            DataFormats.Format image = DataFormats.GetFormat(DataFormats.Bitmap);
            richTextBox1.Paste(image);

        }

        }

        }
